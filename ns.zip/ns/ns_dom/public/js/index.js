/********轮播图*********/
    var i=0;
    var LIWIDTH=1920;
    var DURATION=500;
    var LICOUNT=4;
    var ulImgs=document.getElementById("ul-imgs");
    var ulIdxs=document.getElementById("ul-idxs");
    var lis=ulIdxs.children;
    function moveTo(to){
      if(to==undefined){
        to=i+1;
      }
      if(i==0){
        if(to>i){
          ulImgs.className="transition";
        }else{
          ulImgs.className="";
          ulImgs.style.marginLeft=-LIWIDTH*LICOUNT+"px";
          setTimeout(function(){
            moveTo(LICOUNT-1);
          },100);
          return;
        }
      }
      i=to;
      ulImgs.style.marginLeft=-i*LIWIDTH+"px";
      for(var li of lis){
        li.className=""
      }
      console.log(i);
      if(i==LICOUNT){
        i=0;
        setTimeout(function(){
          ulImgs.className="";
          ulImgs.style.marginLeft=0;
        },DURATION)
      }
      lis[i].className="active";
    }

    var btnLeft=document.getElementById("btn-left");
    var btnRight=document.getElementById("btn-right");
    var canClick=true;
    btnRight.onclick=function(){
      move(1)
    }
    function move(n){
      if(canClick){
        console.log(i+n);
        moveTo(i+n);
        canClick=false;
        setTimeout(function(){
          canClick=true;
        },DURATION+100);
      }
    }
    btnLeft.onclick=function(){
      move(-1);
    }

    var interval=3000;
    var timer=setInterval(function(){
      moveTo()
    },3000);
    var banner=document.getElementById("banner");
    banner.onmouseover=function(){
      clearInterval(timer);
    }
    banner.onmouseout=function(){
      timer=setInterval(function(){
        moveTo()
      },3000);
    }

    var ulIdxs=document.getElementById("ul-idxs");
    var canClick=true;
    ulIdxs.onclick=function(e){
      if(canClick){
        var li=e.target;
        if(li.nodeName=="LI"){
          if(li.className!=="active"){
            for(var i=0;i<lis.length;i++){
              if(lis[i]==li){
                break;
              }
            }
            moveTo(i);
            setTimeout(function(){
              canClick=true;
            },DURATION);
          }
        }
      }
    }
/******侧边栏******/
$(function(){
  //1.1移入li变色
  $(".banner_ul>li").hover(function(){
    $(this).toggleClass("hover")
  })
  //1.2移入li后显示弹出菜单
  var n=1;
  $(".banner_ul>li").mouseenter(function(){
  var $id=$(this).attr("data-id")
  $("#"+$id).removeClass("hidden")
  .css("z-index",n++)
  })
  //鼠标移出ul后隐藏所有弹出菜单
  $(".banner_ul").mouseleave(function(){
    $("#banner_list1,#banner_list2,#banner_list3,#banner_list4").addClass("hidden");
  })
  /******推荐商品*******/ 
  $(".product_ul>li").hover(function(){
    $(this).children(":first-child").children("img").attr("src","img/094353_20969.png")
    $(this).children(":last-child").toggleClass("hidden")
  },
    function(){
      $(this).children(":first-child").children("img").attr("src","img/094350_123422.png")
      $(this).children(":last-child").toggleClass("hidden")
    }
  )
  /*******达人推荐********/ 
  //1.找到鼠标悬停图片，为其绑定鼠标悬停事件
  $(".match_ul>li").mouseenter(function(){
    //1.1获得对应id
    var $id=$(this).attr("id");
    //1.2.找到小箭头，将left改变
    $("#arrows")
    .attr("class","")
    .addClass($id);
  })
})