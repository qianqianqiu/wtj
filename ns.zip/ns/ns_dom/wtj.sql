SET NAMES UTF8;
DROP DATABASE IF EXISTS wtj;
CREATE DATABASE wtj CHARSET=UTF8;
USE wtj;
#首页推荐商品
CREATE TABLE wtj_recommend(
  title VARCHAR(16),
  detail VARCHAR(64),
  type VARCHAR(16),
  pic VARCHAR(128)
);
INSERT INTO wtj_recommend VALUES(
  '斯品家居',
  '斯品北欧宜家涤棉面料蓝色布艺沙发',
  '布艺沙发',
  'img/094350_123422.png'
)
