SET NAMES UTF8;
DROP DATABASE IF EXISTS wtj;
CREATE DATABASE wtj CHARSET=UTF8;
USE wtj;
#首页推荐商品
CREATE TABLE wtj_recommend(
  title VARCHAR(16),
  detail VARCHAR(64),
  type VARCHAR(16),
  pic VARCHAR(128)
);
INSERT INTO wtj_recommend VALUES(
  '斯品家居',
  '斯品北欧宜家涤棉面料蓝色布艺沙发',
  '布艺沙发',
  'img/094350_123422.png'
);
INSERT INTO wtj_recommend VALUES(
  '帕拉多米',
  '帕拉多米简约现代麻布面料混色休闲椅',
  '其他椅子',
  'img/171850_844404.png'
);
INSERT INTO wtj_recommend VALUES(
  '匹美',
  '匹美北欧宜家实木加厚油蜡皮折叠凳',
  '折叠凳',
  'img/101009_919580.png'
);
INSERT INTO wtj_recommend VALUES(
  '九五',
  '九五泊系列北欧宜实木木床',
  '板木结合床',
  'img/154449_895808.png'
);
INSERT INTO wtj_recommend VALUES(
  '以恒尚品',
  '以恒尚品北欧风格板木旋转茶几',
  '茶几',
  'img/175034_437467.png'
);
INSERT INTO wtj_recommend VALUES(
  '富焱灯饰',
  '富焱灯饰北欧宜家玻璃布艺白色台灯',
  '灯具',
  'img/145247_562117.png'
);
INSERT INTO wtj_recommend VALUES(
  '摩图',
  '摩图北欧风格高端棉麻面料白色布艺沙发',
  '布艺沙发',
  'img/093900_284539.png'
);
INSERT INTO wtj_recommend VALUES(
  'Top Art Studio',
  'Top Art Studio欧式风格精细骨瓷杯碟',
  '家品百货',
  'img/111338_624180.png'
);
CREATE TABLE wtj_user(
  uid INT PRIMARY KEY AUTO_INCREMENT,
  uname VARCHAR(32),
  upwd VARCHAR(32)
);
INSERT INTO wtj_user VALUES(
  null,
  'tom',
  'a123'
);
INSERT INTO wtj_user VALUES(
  null,
  'jerry',
  'a1234'
);
CREATE TABLE wtj_cart(
  cid INT PRIMARY KEY AUTO_INCREMENT,
  img VARCHAR(32),
  title VARCHAR(32),
  detail VARCHAR(32),
  uid INT
);
INSERT INTO wtj_cart VALUES(
  null,
  'img/094350_123422.png',
  '斯品北欧宜家绦棉面料深蓝色布艺沙发',
  '布艺沙发',
  1
);
INSERT INTO wtj_cart VALUES(
  null,
  'img/171850_844404.png',
  '帕拉多米简约现代麻布面料混色休闲椅',
  '其他椅子',
  1
);
INSERT INTO wtj_cart VALUES(
  null,
  'img/093900_284539.png',
  '摩图北欧风格高端棉麻面料白色布艺沙发',
  '布艺沙发',
  1
);
INSERT INTO wtj_cart VALUES(
  null,
  'img/145247_562117.png',
  '富焱灯饰北欧宜家玻璃布艺白色台灯',
  '灯具',
  1
);
