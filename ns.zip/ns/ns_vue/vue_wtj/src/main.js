import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
//引入element
import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
Vue.use(ElementUI)
import axios from './axios'
import MyHeader from './components/Navtop.vue'
import Carousel from './components/Carousel.vue'
import MyFooter from './components/Footer.vue'
Vue.component("my-header",MyHeader);
Vue.component("carousel",Carousel);
Vue.component("my-footer",MyFooter);
Vue.config.productionTip = false


new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
