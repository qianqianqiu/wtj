<template>
  <div id="app">
    <router-view/>
  </div>
</template>
<style>
 /* #app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}
#nav {
  padding: 30px;
} 

 #nav a {
  font-weight: bold;
  color: #2c3e50;
} 

 #nav a.router-link-exact-active {
  color: #42b983;
}  */
body{
  font:12px "微软雅黑";
  color:#333333;
  margin:0;
}
ul,ol,p,h1,h2,h3,h4,h5,h6,a{
  padding:0;
  margin:0;
  list-style:none;
}
a{
  color:#333333;
  text-decoration: none;
}
a:hover{
  color:#999999;
}
.lf{
  float:left
}
.rt{
  float:right
}
.clear{
  clear:both
}
.hidden{
  display:none;
}
.fl{
  display:flex
}
</style>
