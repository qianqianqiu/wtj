<template>
  <div>
    <my-header></my-header>
    <div style="min-height:425px;position:relative">
      <div class="box">
        <el-breadcrumb separator="/" class="topBase">
          <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
          <el-breadcrumb-item >购物车</el-breadcrumb-item>
        </el-breadcrumb>
        <div class="cartCenter" v-if="list.length==0">
          <p class="cart"></p>
          <p class="cartTitle">您的购物车没有任何商品，赶快去添加吧！</p>
        </div>
        <!-- 商品列表 -->
        <div v-else>
        <div class="cut"></div>
          <div class="proBox" v-for="(elem,i) of list" :key="i" >
            <div class="leftBox">
              <span>数量：1</span>
              <div class="title">
                <div style="margin-right:20px">
                  <img style="height:125px;width:125px" :src="list[i].img" alt="">
                </div>
                <p class="detail">
                  <span>斯品北欧宜家绦棉面料深蓝色布艺沙发</span>
                  <span style="display:block;margin-top:10px">圆润外观,胖胖的身材,给你更多安全感,让身体沉浸在沙发的舒适怀抱中
                  </span>
                </p>
              </div>
            </div>
            <div>
              小计 <span>6399</span>
                <button style="margin-left:40px" class="proButton" :data-cid="list[i].cid" @click="del">删除</button>
            </div>
          </div>
        </div>
      </div>
    </div>
    <my-footer></my-footer>
  </div>
</template>
<script>
export default {
  data(){
    return{
      list:[]
    }
  },//data
  methods: {
    del(e){
      var obj={cid:e.target.dataset.cid};

      this.axios.get("del",{params:obj}).then(result=>{
        console.log(result);
      })
        this.onload();
    },
    onload(){
      var obj={uid:document.cookie}
      this.axios.get("cart",{params:obj}).then(result=>{

      this.list=result.data

    })
    }
  },
  created(){
    this.onload();
  },
}
</script>
<style scoped>
  .cart{
    width:101px;
    height:92px;
    /* border:1px solid #333; */
    background-image:url(../../public/img/cartico.png);
    background-position:0 -106px;
    margin:0 auto
  }
  .cartCenter{
    position: absolute;
    top:50%;
    left:50%;
    margin-top:-72px;
    margin-left:-228px;
  }
  .cartTitle{
    color:#999;
    font-size: 24px;
    padding-top:20px;
  }
  /* 面包屑下方空间 */
  .topBase{
    margin-top:40px;
    padding-bottom:80px;
  }
  /* 分割线 */
  .cut{
    border-bottom:1px solid #ddd;
  }
  .box{
    width:1200px;
    margin:0 auto;
  }
  .proBox{
    height:156px;
    display:flex;
    border-bottom:1px solid #dddddd;
    justify-content:space-between;
    align-items:center;
    padding:20px 0;
  }
  .leftBox{
    display:flex;
    justify-content:space-between;
    align-items:center;
  }
  .title{
    display:flex;
    justify-content:space-between;
  }
  .leftBox>span:first-child{
    margin-right:150px;
  }
  .detail>span:first-child{
    color:#333;
    font-size:16px;
    font-weight:bold;
    padding-bottom:20px;
  }
  .proButton{
    width:50px;
    height:30px;
    background-color: #fff;
    color:#333;
    border:1px solid #ccc;
    outline: none
  }
</style>
