<template>
  <div>
    <my-header></my-header>
    <div class="detail">
      <el-breadcrumb separator="/" class="topBase">
        <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
        <el-breadcrumb-item :to="{ path: '/' }">商品</el-breadcrumb-item>
        <el-breadcrumb-item>斯品北欧宜家绦棉面料深蓝色布艺沙发</el-breadcrumb-item>
      </el-breadcrumb>
    </div>
    <my-footer></my-footer>
  </div>
</template>
<script>
export default {
  data(){
    return{
      list:[]
    }
  },//data
  methods: {

  },
  created(){

  },
}
</script>
<style scoped>
  .detail{
    width:1200px;
    margin:0 auto
  }
</style>