<template>
  <div>
    <my-header></my-header>
    <!-- 轮播图 -->
    <carousel></carousel> 
    <!-- 页面主体 -->
      <section id="main">
    <!-- 3.1推荐商品 -->
    <div id="main_recommend">
      <!-- 推荐商品logo -->
      <h2></h2>
      <!-- 商品列表(弹性布局) -->
      <ul class="product_ul">
        <li class="location" v-for="(item,i) of list" :key="i">
          <a href="#">
            <img :src="item.pic" alt="">
          </a>
          <span class="title" v-text="item.title"></span><br>
          <span class="detail" v-text="item.detail"></span><br>
          <span class="kind" v-text="item.type"></span>
          <!--弹出框-->
          <div class="product hidden">
            <img src="/img/174732_182906.jpg" alt="">
            <p>斯品家居</p>
            <span>
              斯品北欧宜家绦棉面料深蓝色布<span class="span">大厂直供</span>
            </span>
            <b>￥4464.00</b>
            <div class="one"></div>
            <!--规格尺寸-->
            <div id="size2">
              <p class="lf">规格尺寸：</p>
              <ul class="lf">
                <li>二人位：1400L*800W*880Hmm</li>
                <li>单人位：800L*800W*880Hmm</li>
                <li>三人位：1800L*800W*880Hmm</li>
              </ul>
            </div>
          </div>
        </li>
        <!-- <li>
          <a href="#">
            <img src="img/094350_123422.png" alt="">
          </a>
          <span class="title">斯品家居</span><br>
          <span class="detail">斯品北欧宜家绦棉面料深蓝色布艺沙发</span><br>
          <span class="kind">布艺沙发</span>
        </li>
        <li>
            <a href="#">
              <img src="img/094350_123422.png" alt="">
            </a>
            <span class="title">斯品家居</span><br>
            <span class="detail">斯品北欧宜家绦棉面料深蓝色布艺沙发</span><br>
            <span class="kind">布艺沙发</span>
        </li>
        <li>
          <a href="#">
            <img src="img/094350_123422.png" alt="">
          </a>
          <span class="title">斯品家居</span><br>
          <span class="detail">斯品北欧宜家绦棉面料深蓝色布艺沙发</span><br>
          <span class="kind">布艺沙发</span>
        </li>
        <li>
            <a href="#">
              <img src="img/094350_123422.png" alt="">
            </a>
            <span class="title">斯品家居</span><br>
            <span class="detail">斯品北欧宜家绦棉面料深蓝色布艺沙发</span><br>
            <span class="kind">布艺沙发</span>
        </li>
        <li>
          <a href="#">
            <img src="img/094350_123422.png" alt="">
          </a>
          <span class="title">斯品家居</span><br>
          <span class="detail">斯品北欧宜家绦棉面料深蓝色布艺沙发</span><br>
          <span class="kind">布艺沙发</span>
        </li>
        <li>
          <a href="#">
            <img src="img/094350_123422.png" alt="">
          </a>
          <span class="title">斯品家居</span><br>
          <span class="detail">斯品北欧宜家绦棉面料深蓝色布艺沙发</span><br>
          <span class="kind">布艺沙发</span>
        </li>
        <li>
          <a href="#">
            <img src="img/094350_123422.png" alt="">
          </a>
          <span class="title">斯品家居</span><br>
          <span class="detail">斯品北欧宜家绦棉面料深蓝色布艺沙发</span><br>
          <span class="kind">布艺沙发</span>
        </li> -->
      </ul>
      <!-- 清除浮动 -->
      <div class="clear"></div>
    </div>
    <!-- 分割横线 -->
    <div class="part"></div>
    <!-- 3.2达人搭配 -->
    <div id="match">
      <h2></h2>
      <div class="clear"></div>
      <!-- 下面图片流 -->
      <ul class="match_ul">
        <li id="img1" @mouseenter="ab1"><a href=""><img src="img/20160704034030_342995.png" alt=""></a></li>
        <li id="img2" @mouseenter="ab2"><a href=""><img src="img/20160619183316_599496.png" alt=""></a></li>
        <li id="img3" @mouseenter="ab3"><a href=""><img src="img/20160617181115_678389.png" alt=""></a></li>
        <li id="img4" @mouseenter="ab4"><a href=""><img src="img/20170819152408_648156.png" alt=""></a></li>
      </ul>
      <!-- 图片流下面的分割线 -->
      <div class="match_div">
        <div id="arrows" :class="abn">
          <img src="/img/arrow.png" alt="">
        </div>
      </div>
      <!-- 图片对应的div -->
      <div id="img1_d1">
        
      </div>
      <div id="img2_d2"></div>
      <div id="img3_d3"></div>
      <div id="img4_d4"></div>
    </div>
    
    <!-- 3.3推荐灵感 -->
    <!-- 3.4选购指南 -->
  </section>
  <my-footer></my-footer>
  </div>
</template>
<script>
  import Carousel from '../components/Carousel'

 export default{
    data(){
      return{
        list:[{pic:""}],
        n:-1,
        aphi:{

        },
        abn:{
          img2:false,
          img3:false,
          img4:false
        }
      }
    },//data
    methods:{
      load(){
        this.axios.get("index").then(result=>{
          console.log(result)
          this.list=result.data
          console.log(this.list)
        })
      },
      ab1(){
        this.abn.img2=false;
        this.abn.img3=false;
        this.abn.img4=false
      },
      ab2(){
        this.abn.img2=true;
        this.abn.img3=false;
        this.abn.img4=false
      },
      ab3(){
        this.abn.img2=false;
        this.abn.img3=true;
        this.abn.img4=false
      },
      ab4(){
        this.abn.img2=false;
        this.abn.img3=false;
        this.abn.img4=true
      }
    },
    created(){
      this.load()
    },
    components:{
      'carousel':Carousel
    }
  }
</script>
<style>
  #main,#footer{
  width:1200px;
  margin:0 auto;
  /*border:1px solid #999;*/
}
  #main_recommend{
  margin-top:80px;
}
/* *****推荐商品***** */
/* 推荐商品logo */
#main_recommend>h2{
  width:181px;
  height:44px;
  float:left;
  background-image:url("../../public/img/wtjicon.png");
  background-position:0 -134px;
  margin-bottom:10px;
}
#main_recommend>ul{
  display:flex;
  width:1200px;
  height:830px;
  flex-wrap:wrap;
  align-items:flex-start;
}
#main_recommend>ul>li{
  width:276px;
  height:375px;
  padding:12px;
}
#main_recommend>ul>li:hover{
  background-color:#F0F0F0;
}
#main_recommend>ul>li>a{
  background-color:#fff;
  display:block;
}
/* 列表中图片的大小 */
#main_recommend>ul>li>a>img{
  width:276px;
  height:260px;
}
/* 图片下面的文本 */
.title{
  position: relative;
  top:15px;
}
.detail{
  position: relative;
  top:30px;
  font-size: 14px;
}
.kind{
  position: relative;
  top:35px;
  color:#999;
}
/*推荐商品弹出框*/
.product{
  width:300px;
  height:250px;
  position:absolute;
  background-color:#F0F0F0;
  top:272px;
  left:0;
  padding:12px;
  box-sizing:border-box;
}
.product img{
  width:44px;
  padding-bottom: 12px;
}
.product p{
  color:#999999;
}
.product .span{
  background-color: black;
  border-radius: 2px;
  padding:2px 1px;
  margin-left:15px;
  color:white;
}
/* 规格尺寸 */
#size2{
  padding-top:10px;
  color:#999999;
}
/* 分割线 */
.one{
  width:40px;
  border-top:1px solid black;
}
/*弹出框父元素相对定位*/
.location{
  position:relative;
  line-height:2;
}
/* 分割线  */
.part{
  margin:0 auto;
  width:80px;
  height:80px;
  border-bottom:1px solid #333;
  margin-bottom:160px;
}
/* 达人搭配logo */
#match>h2{
  width:181px;
  height:44px;
  float:left;
  background-image:url("../../public/img/wtjicon.png");
  background-position:0 -181px;
  margin-bottom:10px;
}
/* 达人搭配图片流 */
.match_ul{
  display:flex;
  justify-content:space-between;
}
.match_ul img{
  width:280px;
}
/* 图片流下的分割线 */
.match_div{
  margin-top:30px;
  border-top:1px solid black;
  position: relative;
}
.match_div>div{
  position: absolute;
  top:-14px;
  left:130px;
  transition: .7s;
}

.match_div>div.img2{
  left:430px;
}
.match_div>div.img3{
  left:750px;
}
.match_div>div.img4{
  left:1050px;
}
/* 图片对应的div */

</style>