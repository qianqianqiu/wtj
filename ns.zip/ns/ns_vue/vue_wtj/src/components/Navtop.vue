<template>
  <div>
    <nav id="nav">
      <!--1.1LOGO-->
      <a class="lf" href=""><img src="../../public/img/nansen.jpg" alt=""></a>
      <!--1.2导航列表-->
      <ul class="nav_ul lf">
        <li><a href="">首页</a></li>
        <li><a href="">搭配</a></li>
        <li id="nav_span"><a href="" class="lf">商品</a><span>大厂直供</span></li>
        <li><a href="">灵感</a></li>
        <li class="nav_search"><a href=""></a></li>
      </ul>
      <!--1.3登录-->
        <!-- 1.3.1登录 -->
        <a href="" class="nav_righttwo" v-if="number==''">
          <router-link :to="number==''?url1:url2">
            <img src="../../public/img/login-no.png" alt="">
          </router-link>
          <router-link :to="number==''?url1:url2">
            <img src="../../public/img/arrow-3.png" alt="">
          </router-link>
        </a>
        <div v-else class="car">
          <router-link to="cart">
            <img class="nav_righttwo" style="width:30px;height:30px;" src="../../public/img/cart.png" alt="">
          </router-link>
          <a href="" @click="logout">退出登录</a>
        </div>
        <!-- 1.3.2创建搭配 -->
        <a class="nav_rightone" href="#">
          <img src="../../public/img/mybuild_btn-1.png" alt="">
          <span>创建搭配</span>
        </a>
      <!--1.4空div-->
      <div class="clear"></div>
    </nav>
  </div>
</template>
<script>
  export default{
    data(){
      return{
        list:[],
        url1:"login",
        url2:"cart",
        number:document.cookie
      }
    },//data
    methods:{
      load(){
        this.axios.get("index").then(result=>{
          console.log(result)
          this.list=result.data
          console.log(this.list)
        })
      },
      logout(){
        document.cookie="";
      }
    },
    created(){
      this.load()
    }
  }
</script>
<style scoped>
  #nav{
  padding:20px 37px;
  line-height: 43px;
  border-bottom:1px solid #dddddd;
}
/* logo */
#nav a.lf{
  height:40px;
}
/* 导航列表下的li */
.nav_ul li{
  padding-left:73px;
  float:left;
  font-size:16px;
}
/* 导航列表下的li下的搜索图标 */
.nav_ul .nav_search a{
  float:left;
  width:22px;
  height:22px;
  background-image: url("../../public/img/wtjicon.png");
  position: relative;
  top:10px;
}
.nav_ul .nav_search a:hover{
  background-position:-25px 0;
}
/* 厂家直销 */
#nav_span span{
  padding:2px 2px;
  margin-left:5px;
  font-size: 12px;
  width:48px;
  height:22px;
  background-color: #111111;
  color:#fff;
  border-radius: 3px;
}
/* 创建搭配 */
.nav_rightone{
  float:right;
  width:108px;
  height:30px;
  border-radius:50px;
  background-color: #111111;
  color:#fff;
  margin-top:7px;
  line-height:30px;
  margin-right:80px;
  font-size:12px;
}
/* 创建搭配悬停*/
.nav_rightone:hover{
  opacity:0.8;
  color:#fff;
}
.nav_rightone img{
  position:relative;
  top:4px;
  left:9px;
  padding-right:15px;
  padding-left:5px;
}
/* 登陆 */
.nav_righttwo{
  float:right;
  width:40px;
  height:18px;
  margin-top:4px;
}
.car{
  float: right;
}
</style>