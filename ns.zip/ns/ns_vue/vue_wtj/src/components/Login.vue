<template>
  <div class="before">
    <div class="loginForm">
      <h1>登录南森</h1>
      <p>发现灵感，搜集所爱，美好家居就从这里开始。现在就登录南森搭建您心仪的家吧！</p>

      <p>通过手机或邮箱登录</p>
      <input type="text" placeholder="用户名" v-model="uname"> <br>
      <input type="password" placeholder="密码" v-model="upwd"> <br>
      <div>
        <div>
          <input type="checkbox">
          下次自动登录
        </div> 
        <a href="">忘记密码</a>
      </div>
      <button @click="login">登录</button>
      <p> <span class="noVip">还不是会员？</span><a href="">立即注册</a></p>
    </div>
    <div class="clear"></div>
  </div>
</template>
<script>
  export default{
    data(){
      return{
        uname:"",
        upwd:""
      }
    },//data
    methods:{
      login(){
        var obj={uname:this.uname,upwd:this.upwd}
        this.axios.get("login",{params:obj}).then(result=>{
          if(result.data.code==1){
            document.cookie=result.data.ids;
            this.$router.push({path:'/index'})
          }else{
            this.$alert('用户名或密码错误', '提示', {
          confirmButtonText: '确定'
        });
        return;
          }
        })
      }
    }
  }
</script>
<style scoped>
  .clear{
  clear:both;
  }
  .before{
    background-color: #fff;
    opacity: 0.9;
  }
  .loginForm{
    background-color: #fff;
    opacity: 0.9;
    width:420px;
    margin:0 auto;
    position:absolute;
    top:50%;
    left:50%;
    margin-top:-210px;
    margin-left:-191px;
    /* display:none; */
  }
  .loginForm h1{
    text-align: center;
    line-height:50px;
  }
  .loginForm p:nth-child(2){
    margin-bottom:20px;
  }
  .loginForm p:nth-child(3){
    margin-bottom:20px;
  }
  .loginForm input:nth-child(4){
    width:100%;
    height:48px;
    outline: none;
    border: 1px solid #999;
    padding:0;
    padding-left:20px;
    box-sizing: border-box;
    margin-bottom:20px;
  }
    .loginForm input:nth-child(6){
    width:100%;
    height:48px;
    outline: none;
    border: 1px solid #999;
    padding:0;
    padding-left:20px;
    box-sizing: border-box;
  }
  .loginForm button{
    color:#fff;
    background-color: #111111;
    text-align:center;
    width:100%;
    height:46px;
    font-size: 14px;
    border: 0;
    margin-top:20px;
  }
  .loginForm button:hover{
    opacity: 0.8;
  }
  .loginForm div:nth-child(8){
    margin-top:20px;
    display:flex;
    justify-content:space-between;

  }
  .loginForm p:nth-child(10){
    text-align:center;
    margin-top:10px;
  }
  .noVip{
    color:#999;
  }
</style>