<template>
  <div>
    <el-carousel height="548px" arrow="always">
      <el-carousel-item>
        <img src="../../public/img/144828_478382.jpg" alt="">
      </el-carousel-item>
      <el-carousel-item>
        <img src="../../public/img/140902_335272.jpg" alt="">
      </el-carousel-item>
      <el-carousel-item>
        <img src="../../public/img/152317_133585.jpg" alt="">
      </el-carousel-item>
    </el-carousel>
  </div>
</template>
<script>
  export default{
    data(){
      return{
        
      }
    }
  }
</script>
<style>

</style>