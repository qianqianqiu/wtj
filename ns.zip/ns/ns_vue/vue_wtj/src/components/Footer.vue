<template>
  <div class="bg">
    <ul class="footerUl">
      <li class="footerLi">
        <i></i>
        <div>
          <span>大厂直供</span> <br>
          <span>出厂价格出口品质</span>
        </div>
      </li>
      <li class="footerLi">
        <i class="footeri2"></i>
        <div>
          <span>家居灵感</span> <br>
          <span>海量家居美图发现梦想的家</span>
        </div>
      </li>
      <li class="footerLi">
        <i class="footeri3"></i>
        <div>
          <span>私人搭配师</span> <br>
          <span>资深设计师免费帮你搭</span>
        </div>
      </li>
    </ul>
    <!-- 页脚第二个ul -->
    <ul class="footerUl2">
      <li>
        <img src="../../public/img/nansen2.jpg" alt="">
        <p>粤ICP备15037979号-1 <br>©2015~2018 wutuojia.com 北京南森信息科技有限公司</p>
      </li>
      <li>
        <ul class="about">
          <li class="ul2li">关于我们</li>
          <li>关于乌托家</li>
          <li>战略合作</li>
          <li>社会招聘</li>
        </ul>
      </li>
      <li>
        <ul class="about">
          <li class="ul2li">帮助中心</li>
          <li>用户指南</li>
          <li>常见问题</li>
          <li>意见反馈</li>
        </ul>
      </li>
      <li>
        <ul class="about">
          <li class="ul2li">配送安装</li>
          <li>配送服务</li>
          <li>安装服务</li>
          <li>收货指南</li>
        </ul>
      </li>
      <li>
        <ul class="about">
          <li class="ul2li">售后保障</li>
          <li>退货政策</li>
          <li>退货流程</li>
          <li>联系我们</li>
        </ul>
      </li>
      <li class="qrCode">
        <img src="../../public/img/qrcode.png" alt="">
        <br>
        <span>关注南森公众号</span>
      </li>
    </ul>
  </div>
</template>
<script>
export default {
  data(){
    return{

    }
  }
}
</script>
<style>
  div.bg{
    margin-top:100px;
    background-color:#f0f0f0;
  }
  .footerUl{
    width:1200px;
    margin:0 auto;
    display:flex;
    justify-content:space-between;
    align-items:center;
    padding:40px 0;
    border-bottom:1px solid #dddddd
  }
  .footerLi{
    display:flex;
    align-items:center
  }
  .footerLi>i{
    width:58px;
    height:36px;
    background-image: url(../../public/img/b_ic.png);
  }
  .footerLi>div{
    padding-left:15px;
  }
  .footerLi h2{
    padding-bottom:5px;
  }
  .footerLi>div>span:first-child{
    font-size:24px;
  }
  .footerLi>div>span:last-child{
    font-size:16px;
    color:#999;
  }
  .footerLi .footeri2{
    width:46px;
    height:49px;
    background-position:-66px; 
  }
  .footerLi .footeri3{
    width:47px;
    height:47px;
    background-position:-123px; 
  }
  .footerUl2{
    display:flex;
    width:1200px;
    margin:0 auto;
    display:flex;
    justify-content:space-between;
    padding:40px 0;
  }
  .footerUl2 .ul2li{
    font-size: 18px;
    color:#333;
    padding-bottom:15px;
  }
  .footerUl2>li>p{
    color:#999999;
    padding-top:62px;
  }
  .about>li{
    color:#999999;
    padding-bottom:8px;
  }
  .qrCode{
    text-align: center;
  }
  .footerUl2 .qrCode span{
    padding-top: 10px;
    color:#999999;
  }
</style>
